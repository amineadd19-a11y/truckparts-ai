'use client';

type Status =
  | 'verified'
  | 'cross-checked'
  | 'needs-verification'
  | 'VERIFIED'
  | 'CROSS-CHECKED'
  | 'NEEDS_VERIFICATION'
  | 'DEMO_DATA'
  | string;

interface VerificationBadgeProps {
  status: Status;
  size?: 'sm' | 'md' | 'lg';
}

export default function VerificationBadge({ status, size = 'md' }: VerificationBadgeProps) {
  const normalized = (status || '').toString().toUpperCase().replace(/-/g, '_');

  let style = 'bg-yellow-100 text-yellow-800';
  let label = '⚠ Needs Verification';

  if (normalized === 'VERIFIED') {
    style = 'bg-green-100 text-green-800';
    label = '✓ Verified';
  } else if (normalized === 'CROSS_CHECKED' || normalized === 'CROSSCHECKED') {
    style = 'bg-blue-100 text-blue-800';
    label = '✓ Cross-Checked';
  } else if (normalized === 'DEMO_DATA' || normalized === 'DEMODATA') {
    style = 'bg-orange-100 text-orange-800';
    label = 'DEMO DATA';
  }

  const sizeStyles = {
    sm: 'text-xs px-2 py-1',
    md: 'text-sm px-3 py-1.5',
    lg: 'text-base px-4 py-2',
  };

  return (
    <span className={`inline-block rounded-full font-semibold ${style} ${sizeStyles[size]}`}>
      {label}
    </span>
  );
}
