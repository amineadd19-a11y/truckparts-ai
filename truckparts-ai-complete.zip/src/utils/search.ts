/**
 * Search and filtering utilities + local AI assistant logic
 */

import { Part } from '@/types/catalog';
import {
  DEMO_PARTS,
  DEMO_CROSS_REFERENCES,
  DEMO_COMPATIBILITY,
  DEMO_TRUCKS,
} from '@/types/catalog';

/**
 * Debounce function for search
 */
export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number,
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

/**
 * Full-text search across parts
 */
export const searchParts = (query: string, parts: Part[] = DEMO_PARTS): Part[] => {
  const normalizedQuery = query.toLowerCase().trim();
  if (!normalizedQuery) return parts;

  return parts.filter(
    (part) =>
      part.name.toLowerCase().includes(normalizedQuery) ||
      part.oem.toLowerCase().includes(normalizedQuery) ||
      part.description?.toLowerCase().includes(normalizedQuery) ||
      part.category.toLowerCase().includes(normalizedQuery),
  );
};

/**
 * Filter parts by category
 */
export const filterPartsByCategory = (parts: Part[], category: string): Part[] => {
  return parts.filter((part) => part.category === category);
};

/**
 * Sort parts by relevance
 */
export const sortPartsByRelevance = (parts: Part[], query: string): Part[] => {
  const normalized = query.toLowerCase();
  return [...parts].sort((a, b) => {
    const aMatchName = a.name.toLowerCase().startsWith(normalized)
      ? 2
      : a.name.toLowerCase().includes(normalized)
        ? 1
        : 0;
    const bMatchName = b.name.toLowerCase().startsWith(normalized)
      ? 2
      : b.name.toLowerCase().includes(normalized)
        ? 1
        : 0;
    const aOem = a.oem.toLowerCase().includes(normalized) ? 1 : 0;
    const bOem = b.oem.toLowerCase().includes(normalized) ? 1 : 0;
    return bMatchName + bOem - (aMatchName + aOem);
  });
};

/**
 * Local AI Assistant — answers natural language questions using catalogue data only
 * Never hallucinates compatibility; clearly labels demo data
 */
export interface AIResponse {
  answer: string;
  matchedParts: Part[];
  confidence: 'high' | 'medium' | 'low' | 'none';
  isDemo: boolean;
}

export function askPartsAI(question: string, language: 'en' | 'fr' | 'ar' = 'en'): AIResponse {
  const q = question.toLowerCase().trim();
  const isDemo = true;

  if (!q) {
    return {
      answer:
        language === 'ar'
          ? 'اكتب سؤالك عن قطع الشاحنات (مثال: فلتر زيت، فرامل، بديل لـ OEM...)'
          : language === 'fr'
            ? 'Posez une question sur les pièces (ex: filtre à huile, freins, alternative OEM...)'
            : 'Ask about truck parts (e.g. oil filter, brakes, OEM alternative...)',
      matchedParts: [],
      confidence: 'none',
      isDemo,
    };
  }

  const keywords: Record<string, string[]> = {
    filter: ['filter', 'filtre', 'فلتر', 'oil', 'air', 'fuel', 'cabin'],
    brake: ['brake', 'frein', 'فرامل', 'pad', 'disc', 'plaquette'],
    electrical: ['alternator', 'starter', 'électrique', 'كهرباء', 'دينامو', 'سلف'],
    engine: ['water pump', 'thermostat', 'pompe', 'مضخة', 'ثرموستات', 'cooling'],
    transmission: ['clutch', 'embrayage', 'قابض', 'transmission'],
    suspension: ['shock', 'absorber', 'suspension', 'امتصاص'],
  };

  let matched: Part[] = [];

  for (const [cat, words] of Object.entries(keywords)) {
    if (words.some((w) => q.includes(w))) {
      matched = DEMO_PARTS.filter(
        (p) =>
          p.category.toLowerCase().includes(cat) ||
          p.name.toLowerCase().includes(cat) ||
          words.some(
            (w) =>
              p.name.toLowerCase().includes(w) || p.description.toLowerCase().includes(w),
          ),
      );
      break;
    }
  }

  if (matched.length === 0) {
    matched = searchParts(q);
  }

  const wantsAlternative =
    q.includes('alternative') ||
    q.includes('cross') ||
    q.includes('substitute') ||
    q.includes('بديل') ||
    q.includes('équivalent') ||
    q.includes('remplacement');

  if (matched.length > 0 && wantsAlternative) {
    const refs = DEMO_CROSS_REFERENCES.filter((cr) =>
      matched.some((m) => m.id === cr.originalPartId),
    );
    const altText =
      refs.length > 0
        ? refs.map((r) => `${r.alternativeOem} (${r.manufacturer})`).join(', ')
        : language === 'ar'
          ? 'لا توجد بدائل مسجلة في الكتالوج التجريبي حالياً.'
          : language === 'fr'
            ? 'Aucune alternative enregistrée dans le catalogue de démo.'
            : 'No registered alternatives in the current demo catalogue.';

    return {
      answer:
        language === 'ar'
          ? `وجدت ${matched.length} قطعة/قطع. البدائل المتاحة: ${altText}. تنبيه: جميع البيانات تجريبية.`
          : language === 'fr'
            ? `J'ai trouvé ${matched.length} pièce(s). Alternatives: ${altText}. Note: données de démonstration uniquement.`
            : `Found ${matched.length} part(s). Alternatives: ${altText}. Note: all data is DEMO only.`,
      matchedParts: matched.slice(0, 6),
      confidence: 'medium',
      isDemo,
    };
  }

  const wantsCompat =
    q.includes('compatible') ||
    q.includes('fit') ||
    q.includes('compatib') ||
    q.includes('يناسب') ||
    q.includes('توافق');

  if (matched.length > 0 && wantsCompat) {
    const compat = DEMO_COMPATIBILITY.filter(
      (c) => matched.some((m) => m.id === c.partId) && c.compatible,
    );
    const trucks = compat
      .map((c) => DEMO_TRUCKS.find((t) => t.id === c.truckId)?.model)
      .filter(Boolean);

    return {
      answer:
        language === 'ar'
          ? `القطع المطابقة متوافقة (تجريبياً) مع: ${trucks.length ? trucks.join(', ') : 'لا بيانات توافق كافية'}. تنبيه: بيانات تجريبية فقط.`
          : language === 'fr'
            ? `Pièces compatibles (démo) avec: ${trucks.length ? trucks.join(', ') : 'données insuffisantes'}. Note: démo uniquement.`
            : `Matching parts are (demo) compatible with: ${trucks.length ? trucks.join(', ') : 'insufficient data'}. Note: DEMO data only.`,
      matchedParts: matched.slice(0, 6),
      confidence: 'medium',
      isDemo,
    };
  }

  if (matched.length > 0) {
    const names = matched
      .slice(0, 5)
      .map((p) => `${p.name} (${p.oem})`)
      .join('; ');
    return {
      answer:
        language === 'ar'
          ? `وجدت ${matched.length} نتيجة: ${names}. جميع البيانات تجريبية وليست للتعريف الفعلي للقطع.`
          : language === 'fr'
            ? `J'ai trouvé ${matched.length} résultat(s): ${names}. Données de démonstration uniquement.`
            : `Found ${matched.length} result(s): ${names}. All data is DEMO — not for real part identification.`,
      matchedParts: matched.slice(0, 8),
      confidence: matched.length >= 3 ? 'high' : 'medium',
      isDemo,
    };
  }

  return {
    answer:
      language === 'ar'
        ? 'لم أجد تطابقاً موثقاً في الكتالوج الحالي. جرب كلمات مثل: فلتر زيت، فرامل، دينامو، أو رقم OEM.'
        : language === 'fr'
          ? "Aucune correspondance vérifiée dans le catalogue. Essayez: filtre à huile, freins, alternateur, ou un numéro OEM."
          : "Couldn't find a verified match in the current catalogue. Try: oil filter, brakes, alternator, or an OEM number.",
    matchedParts: [],
    confidence: 'none',
    isDemo,
  };
}

/**
 * Simple image identification mock based on filename
 * Real Vision API can be plugged via VISION_API_KEY later
 */
export function mockImageIdentify(fileName: string): AIResponse {
  const name = fileName.toLowerCase();
  let query = '';
  if (name.includes('oil') || name.includes('filter')) query = 'oil filter';
  else if (name.includes('brake') || name.includes('pad')) query = 'brake';
  else if (name.includes('air')) query = 'air filter';
  else if (name.includes('alternator') || name.includes('dynamo')) query = 'alternator';
  else if (name.includes('fuel')) query = 'fuel filter';
  else query = name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');

  const result = askPartsAI(query || 'filter');
  return {
    ...result,
    answer: `[Image analysis mock] Based on filename "${fileName}": ${result.answer}`,
  };
}
