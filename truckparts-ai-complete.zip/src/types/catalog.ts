/**
 * Unified catalog types and demo data for TruckParts AI
 * All technical data is clearly marked as DEMO DATA
 */

export type VerificationStatus =
  | 'VERIFIED'
  | 'CROSS-CHECKED'
  | 'NEEDS_VERIFICATION'
  | 'DEMO_DATA';

export interface Manufacturer {
  id: string;
  name: string;
  logo?: string;
  country?: string;
  description?: string;
  verification: VerificationStatus;
}

export interface Engine {
  id: string;
  manufacturer: string;
  model: string;
  displacement?: number;
  cylinders?: number;
  power?: number;
  torque?: number;
  verification: VerificationStatus;
}

export interface Truck {
  id: string;
  manufacturerId: string;
  model: string;
  year: number;
  engineId?: string;
  axles?: number;
  maxGvwr?: number;
  cabType?: string;
  verification: VerificationStatus;
}

export interface Part {
  id: string;
  name: string;
  oem: string;
  category: string;
  description: string;
  price: number;
  availability: 'in-stock' | 'limited' | 'out-of-stock';
  verification: VerificationStatus;
  systemId?: string;
  images?: PartImage[];
  oemReferences?: OEMReference[];
}

export interface OEMReference {
  id: string;
  partId: string;
  manufacturerId: string;
  referenceNumber: string;
  verificationStatus: 'verified' | 'unverified';
}

export interface CrossReference {
  id: string;
  originalPartId: string;
  alternativeOem: string;
  manufacturer: string;
  compatibility: string;
  verification: VerificationStatus;
}

export interface Compatibility {
  id: string;
  partId: string;
  truckId: string;
  engineId?: string;
  compatible: boolean;
  notes?: string;
  verification: VerificationStatus;
}

export interface PartImage {
  id: string;
  partId: string;
  url: string;
  title: string;
  license: string;
  source: string;
}

export interface Source {
  id: string;
  name: string;
  type: string;
  verified: boolean;
}

/** Manufacturers shown on homepage */
export const TRUCK_MANUFACTURERS = [
  { id: 'volvo', name: 'Volvo Trucks', logo: '🚛', country: 'Sweden' },
  { id: 'daf', name: 'DAF', logo: '🚛', country: 'Netherlands' },
  { id: 'scania', name: 'Scania', logo: '🚛', country: 'Sweden' },
  { id: 'man', name: 'MAN', logo: '🚛', country: 'Germany' },
  { id: 'mercedes', name: 'Mercedes-Benz Trucks', logo: '🚛', country: 'Germany' },
  { id: 'renault', name: 'Renault Trucks', logo: '🚛', country: 'France' },
  { id: 'iveco', name: 'Iveco', logo: '🚛', country: 'Italy' },
];

export const DEMO_SYSTEMS = [
  { id: 'engine', name: 'Engine & Cooling', category: 'engine' },
  { id: 'transmission', name: 'Transmission', category: 'transmission' },
  { id: 'suspension', name: 'Suspension', category: 'suspension' },
  { id: 'brake', name: 'Brake System', category: 'brake' },
  { id: 'electrical', name: 'Electrical', category: 'electrical' },
  { id: 'filters', name: 'Filters', category: 'filters' },
  { id: 'other', name: 'Other', category: 'other' },
];

/** DEMO DATA — NOT FOR ACTUAL PART IDENTIFICATION */
export const DEMO_PARTS: Part[] = [
  {
    id: 'p1',
    name: 'Engine Oil Filter',
    oem: 'DEMO-OEM-20430612',
    category: 'Filters',
    description: '[DEMO] High-efficiency engine oil filter for heavy-duty diesel engines.',
    price: 45,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'filters',
    oemReferences: [
      { id: 'oem-1', partId: 'p1', manufacturerId: 'volvo', referenceNumber: 'DEMO-OEM-20430612', verificationStatus: 'unverified' },
    ],
  },
  {
    id: 'p2',
    name: 'Air Filter',
    oem: 'DEMO-OEM-20545956',
    category: 'Filters',
    description: '[DEMO] Primary air filter element for turbocharged engines.',
    price: 35,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'filters',
  },
  {
    id: 'p3',
    name: 'Cabin Air Filter',
    oem: 'DEMO-OEM-20898145',
    category: 'Filters',
    description: '[DEMO] Cabin pollen and particle filter.',
    price: 28,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'filters',
  },
  {
    id: 'p4',
    name: 'Fuel Filter',
    oem: 'DEMO-OEM-20413315',
    category: 'Filters',
    description: '[DEMO] Diesel fuel filter with water separator.',
    price: 52,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'filters',
  },
  {
    id: 'p5',
    name: 'Brake Pad Set (Front)',
    oem: 'DEMO-OEM-21302503',
    category: 'Brakes',
    description: '[DEMO] Front axle ceramic brake pad set for heavy trucks.',
    price: 185,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'brake',
  },
  {
    id: 'p6',
    name: 'Alternator 24V 120A',
    oem: 'DEMO-OEM-20399387',
    category: 'Electrical',
    description: '[DEMO] High-output alternator for commercial vehicles.',
    price: 425,
    availability: 'limited',
    verification: 'DEMO_DATA',
    systemId: 'electrical',
  },
  {
    id: 'p7',
    name: 'Water Pump',
    oem: 'DEMO-OEM-21567890',
    category: 'Engine',
    description: '[DEMO] Engine cooling water pump assembly.',
    price: 165,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'engine',
  },
  {
    id: 'p8',
    name: 'Thermostat',
    oem: 'DEMO-OEM-21678901',
    category: 'Engine',
    description: '[DEMO] Engine coolant thermostat 82°C.',
    price: 38,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'engine',
  },
  {
    id: 'p9',
    name: 'Clutch Kit',
    oem: 'DEMO-OEM-21789012',
    category: 'Transmission',
    description: '[DEMO] Complete clutch kit including disc, pressure plate and release bearing.',
    price: 680,
    availability: 'limited',
    verification: 'DEMO_DATA',
    systemId: 'transmission',
  },
  {
    id: 'p10',
    name: 'Shock Absorber (Rear)',
    oem: 'DEMO-OEM-21890123',
    category: 'Suspension',
    description: '[DEMO] Heavy-duty rear shock absorber.',
    price: 145,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'suspension',
  },
  {
    id: 'p11',
    name: 'Brake Disc (Front)',
    oem: 'DEMO-OEM-21901234',
    category: 'Brakes',
    description: '[DEMO] Ventilated front brake disc.',
    price: 95,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'brake',
  },
  {
    id: 'p12',
    name: 'Starter Motor 24V',
    oem: 'DEMO-OEM-22012345',
    category: 'Electrical',
    description: '[DEMO] 24V heavy-duty starter motor.',
    price: 310,
    availability: 'in-stock',
    verification: 'DEMO_DATA',
    systemId: 'electrical',
  },
];

export const DEMO_MANUFACTURERS: Manufacturer[] = [
  { id: '1', name: 'Volvo', country: 'Sweden', logo: 'https://via.placeholder.com/100?text=Volvo', description: 'Premium truck manufacturer', verification: 'DEMO_DATA' },
  { id: '2', name: 'DAF', country: 'Netherlands', logo: 'https://via.placeholder.com/100?text=DAF', description: 'European truck leader', verification: 'DEMO_DATA' },
  { id: '3', name: 'Scania', country: 'Sweden', logo: 'https://via.placeholder.com/100?text=Scania', description: 'Heavy-duty truck manufacturer', verification: 'DEMO_DATA' },
  { id: '4', name: 'MAN', country: 'Germany', logo: 'https://via.placeholder.com/100?text=MAN', description: 'German engineering trucks', verification: 'DEMO_DATA' },
];

export const DEMO_ENGINES: Engine[] = [
  { id: 'e1', manufacturer: 'Volvo', model: 'D13', displacement: 12780, cylinders: 6, power: 420, torque: 2100, verification: 'DEMO_DATA' },
  { id: 'e2', manufacturer: 'Volvo', model: 'D11', displacement: 10780, cylinders: 6, power: 350, torque: 1700, verification: 'DEMO_DATA' },
  { id: 'e3', manufacturer: 'DAF', model: 'MX-13', displacement: 12900, cylinders: 6, power: 440, torque: 2100, verification: 'DEMO_DATA' },
  { id: 'e4', manufacturer: 'Scania', model: 'DC13', displacement: 12700, cylinders: 6, power: 450, torque: 2350, verification: 'DEMO_DATA' },
];

export const DEMO_TRUCKS: Truck[] = [
  { id: 't1', manufacturerId: '1', model: 'FH16', year: 2022, engineId: 'e1', axles: 3, maxGvwr: 25000, cabType: 'Sleeper', verification: 'DEMO_DATA' },
  { id: 't2', manufacturerId: '1', model: 'FH', year: 2021, engineId: 'e2', axles: 3, maxGvwr: 25000, cabType: 'Sleeper', verification: 'DEMO_DATA' },
  { id: 't3', manufacturerId: '2', model: 'XF', year: 2020, engineId: 'e3', axles: 3, maxGvwr: 26000, cabType: 'Sleeper', verification: 'DEMO_DATA' },
  { id: 't4', manufacturerId: '3', model: 'R450', year: 2023, engineId: 'e4', axles: 3, maxGvwr: 26000, cabType: 'Sleeper', verification: 'DEMO_DATA' },
];

export const DEMO_CROSS_REFERENCES: CrossReference[] = [
  { id: 'cr1', originalPartId: 'p1', alternativeOem: 'DEMO-ALT-20430500', manufacturer: 'Alternative Supplier', compatibility: 'Direct replacement', verification: 'DEMO_DATA' },
  { id: 'cr2', originalPartId: 'p2', alternativeOem: 'DEMO-ALT-20545900', manufacturer: 'Alternative Supplier', compatibility: 'Direct replacement', verification: 'DEMO_DATA' },
  { id: 'cr3', originalPartId: 'p5', alternativeOem: 'DEMO-ALT-21302500', manufacturer: 'Aftermarket', compatibility: 'Equivalent quality', verification: 'DEMO_DATA' },
];

export const DEMO_COMPATIBILITY: Compatibility[] = [
  { id: 'c1', partId: 'p1', truckId: 't1', engineId: 'e1', compatible: true, notes: 'Direct fit - Demo data only', verification: 'DEMO_DATA' },
  { id: 'c2', partId: 'p1', truckId: 't2', engineId: 'e2', compatible: true, notes: 'Direct fit - Demo data only', verification: 'DEMO_DATA' },
  { id: 'c3', partId: 'p5', truckId: 't1', engineId: 'e1', compatible: true, notes: 'Front axle - Demo data only', verification: 'DEMO_DATA' },
  { id: 'c4', partId: 'p6', truckId: 't1', engineId: 'e1', compatible: true, notes: 'Electrical system - Demo', verification: 'DEMO_DATA' },
  { id: 'c5', partId: 'p7', truckId: 't3', engineId: 'e3', compatible: true, notes: 'Cooling system - Demo', verification: 'DEMO_DATA' },
];

export const DEMO_PART_IMAGES: PartImage[] = [
  { id: 'img1', partId: 'p1', url: 'https://via.placeholder.com/300x300?text=Oil+Filter', title: 'Oil Filter', license: 'Demo', source: 'Demo Database' },
  { id: 'img2', partId: 'p2', url: 'https://via.placeholder.com/300x300?text=Air+Filter', title: 'Air Filter', license: 'Demo', source: 'Demo Database' },
  { id: 'img3', partId: 'p5', url: 'https://via.placeholder.com/300x300?text=Brake+Pads', title: 'Brake Pads', license: 'Demo', source: 'Demo Database' },
  { id: 'img4', partId: 'p6', url: 'https://via.placeholder.com/300x300?text=Alternator', title: 'Alternator', license: 'Demo', source: 'Demo Database' },
];
