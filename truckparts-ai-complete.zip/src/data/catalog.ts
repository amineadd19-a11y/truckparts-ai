/**
 * Re-export unified demo data from types/catalog for backward compatibility
 */
export {
  DEMO_PARTS,
  DEMO_TRUCKS,
  DEMO_MANUFACTURERS,
  DEMO_ENGINES,
  DEMO_COMPATIBILITY,
  DEMO_CROSS_REFERENCES,
  DEMO_PART_IMAGES,
  TRUCK_MANUFACTURERS,
  DEMO_SYSTEMS,
} from '@/types/catalog';

export type {
  Part,
  Truck,
  Manufacturer,
  Engine,
  Compatibility,
  CrossReference,
  PartImage,
  Source,
  VerificationStatus,
} from '@/types/catalog';
