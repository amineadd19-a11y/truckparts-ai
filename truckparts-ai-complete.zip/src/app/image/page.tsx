'use client';

import { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, Camera } from 'lucide-react';
import PartCard from '@/components/catalog/PartCard';
import { mockImageIdentify, AIResponse } from '@/utils/search';
import { useAppStore } from '@/store';
import { getTranslation } from '@/data/translations';
import AdSlot from '@/components/ads/AdSlot';

export default function ImageIdentifyPage() {
  const { language } = useAppStore();
  const t = (key: string) => getTranslation(key, language);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [result, setResult] = useState<AIResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File | null) => {
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setResult(null);
  };

  const analyze = () => {
    if (!file) return;
    setLoading(true);
    setTimeout(() => {
      const res = mockImageIdentify(file.name);
      setResult(res);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
          <Camera size={28} />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t('image.title')}</h1>
          <p className="text-gray-600 text-sm">
            {language === 'ar'
              ? 'رفع صورة جزء وربطه بالكتالوج (نسخة تجريبية محلية)'
              : language === 'fr'
                ? 'Téléchargez une photo de pièce (analyse locale de démo)'
                : 'Upload a part photo for local demo matching'}
          </p>
        </div>
      </div>

      <div className="mb-6 bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
        <strong>Note:</strong> {t('image.noService')} {t('common.demo')}
      </div>

      <div
        className="border-2 border-dashed border-gray-300 rounded-xl p-10 text-center bg-white hover:border-blue-400 transition cursor-pointer"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const f = e.dataTransfer.files?.[0];
          if (f && f.type.startsWith('image/')) handleFile(f);
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0] || null)}
        />
        {preview ? (
          <div className="space-y-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={preview}
              alt="Preview"
              className="max-h-64 mx-auto rounded-lg shadow"
            />
            <p className="text-sm text-gray-600">{file?.name}</p>
          </div>
        ) : (
          <>
            <Upload className="mx-auto text-gray-400 mb-3" size={40} />
            <p className="text-gray-700 font-medium">{t('image.upload')}</p>
            <p className="text-sm text-gray-500 mt-1">PNG, JPG, WEBP</p>
          </>
        )}
      </div>

      {file && (
        <div className="mt-6 flex justify-center">
          <button
            onClick={analyze}
            disabled={loading}
            className="px-8 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition flex items-center gap-2"
          >
            <ImageIcon size={18} />
            {loading ? t('image.analyzing') : t('ai.search')}
          </button>
        </div>
      )}

      {result && !loading && (
        <div className="mt-10">
          <div className="p-5 rounded-xl border bg-indigo-50 border-indigo-200 mb-6">
            <h2 className="font-semibold text-gray-900 mb-2">{t('ai.result')}</h2>
            <p className="text-gray-800">{result.answer}</p>
          </div>
          {result.matchedParts.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {result.matchedParts.map((part) => (
                <PartCard key={part.id} part={part} />
              ))}
            </div>
          )}
        </div>
      )}

      <div className="mt-12">
        <AdSlot placement="image-page" />
      </div>
    </div>
  );
}
