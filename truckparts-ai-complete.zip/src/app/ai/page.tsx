'use client';

import { useState } from 'react';
import { Bot, Send } from 'lucide-react';
import PartCard from '@/components/catalog/PartCard';
import { askPartsAI, AIResponse } from '@/utils/search';
import { useAppStore } from '@/store';
import { getTranslation } from '@/data/translations';
import AdSlot from '@/components/ads/AdSlot';

export default function AIPage() {
  const { language } = useAppStore();
  const t = (key: string) => getTranslation(key, language);
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState<AIResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<{ q: string; a: string }[]>([]);

  const handleAsk = () => {
    if (!question.trim()) return;
    setLoading(true);
    // Simulate slight delay for UX
    setTimeout(() => {
      const res = askPartsAI(question, language);
      setResponse(res);
      setHistory((h) => [{ q: question, a: res.answer }, ...h].slice(0, 10));
      setLoading(false);
    }, 400);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white">
          <Bot size={28} />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t('ai.title')}</h1>
          <p className="text-gray-600 text-sm">
            {language === 'ar'
              ? 'مساعد محلي يعتمد على كتالوج البيانات التجريبية فقط'
              : language === 'fr'
                ? 'Assistant local basé uniquement sur le catalogue de démo'
                : 'Local assistant powered only by the demo catalogue'}
          </p>
        </div>
      </div>

      <div className="mb-6 bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
        <strong>Note:</strong> {t('common.demo')}
      </div>

      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-8">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {t('ai.placeholder')}
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
            placeholder={t('ai.placeholder')}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
          <button
            onClick={handleAsk}
            disabled={loading || !question.trim()}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition flex items-center gap-2"
          >
            <Send size={18} />
            {t('ai.search')}
          </button>
        </div>

        {/* Quick suggestions */}
        <div className="mt-4 flex flex-wrap gap-2">
          {(language === 'ar'
            ? ['فلتر زيت', 'فرامل أمامية', 'بديل OEM', 'دينامو 24V']
            : language === 'fr'
              ? ['filtre à huile', 'plaquettes frein', 'alternative OEM', 'alternateur 24V']
              : ['oil filter', 'front brakes', 'OEM alternative', '24V alternator']
          ).map((s) => (
            <button
              key={s}
              onClick={() => {
                setQuestion(s);
                setTimeout(() => {
                  const res = askPartsAI(s, language);
                  setResponse(res);
                  setHistory((h) => [{ q: s, a: res.answer }, ...h].slice(0, 10));
                }, 100);
              }}
              className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700 transition"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {loading && (
        <div className="text-center py-8 text-gray-500">{t('common.loading')}</div>
      )}

      {response && !loading && (
        <div className="mb-10">
          <div
            className={`p-5 rounded-xl border mb-6 ${
              response.confidence === 'none'
                ? 'bg-gray-50 border-gray-200'
                : 'bg-blue-50 border-blue-200'
            }`}
          >
            <h2 className="font-semibold text-gray-900 mb-2">{t('ai.result')}</h2>
            <p className="text-gray-800 whitespace-pre-wrap">{response.answer}</p>
            <p className="text-xs text-gray-500 mt-3">
              Confidence: {response.confidence} {response.isDemo && '• DEMO DATA'}
            </p>
          </div>

          {response.matchedParts.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {response.matchedParts.map((part) => (
                <PartCard key={part.id} part={part} />
              ))}
            </div>
          )}
        </div>
      )}

      {history.length > 0 && (
        <div className="mt-8">
          <h3 className="font-semibold text-gray-900 mb-3">
            {language === 'ar' ? 'السجل' : language === 'fr' ? 'Historique' : 'History'}
          </h3>
          <ul className="space-y-2 text-sm">
            {history.map((h, i) => (
              <li key={i} className="bg-gray-50 rounded-lg p-3">
                <span className="font-medium text-gray-700">Q:</span> {h.q}
                <br />
                <span className="text-gray-600">A: {h.a.slice(0, 120)}...</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-12">
        <AdSlot placement="ai-page" />
      </div>
    </div>
  );
}
